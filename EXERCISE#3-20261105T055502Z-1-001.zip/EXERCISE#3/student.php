<!DOCTYPE html>
<html>
<head>
    <title>PHP GET Request - Student Portal</title>
</head>
<body>

    <h2>Student Information Form</h2>

    <!-- Form submits using the GET method to student.php -->
    <form action="student.php" method="GET">
        <label>Name:</label><br>
        <input type="text" name="name" placeholder="Enter full name" required><br><br>

        <label>School:</label><br>
        <input type="text" name="school" placeholder="Enter school" required><br><br>

        <label>Course:</label><br>
        <input type="text" name="course" placeholder="Enter course" required><br><br>

        <label>Subject:</label><br>
        <input type="text" name="subject" placeholder="Enter subject" required><br><br>

        <input type="submit" value="Submit Request">
    </form>

    <hr>

    <?php
    // Read parameters sent through the GET request
    if (isset($_GET['name'])) {
        $name    = $_GET['name'];
        $school  = $_GET['school'];
        $course  = $_GET['course'];
        $subject = $_GET['subject'];

        echo "<h2>Greetings, " . $name . "!</h2>";
        echo "<p>Welcome to <strong>" . $school . "</strong>.</p>";
        echo "<h3>Submitted Record:</h3>";
        echo "<ul>";
        echo "<li><strong>Student Name:</strong> " . $name . "</li>";
        echo "<li><strong>School:</strong> " . $school . "</li>";
        echo "<li><strong>Course:</strong> " . $course . "</li>";
        echo "<li><strong>Subject:</strong> " . $subject . "</li>";
        echo "</ul>";
    }
    ?>

</body>
</html>